from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Job_Listing, Contract_Type, Job_Application
from user.models import Job_Applicant
from django.contrib.auth.models import User

# Create your views here.


def add_job(request):
    # Check if use is logged in
    if request.user.is_authenticated:

        if request.method == 'POST':
            job = Job_Listing()

            # Fill in job listing information
            job.job_title = request.POST.get('job_title')
            job.total_skills = request.POST.get('total_skills')
            job.start_date = request.POST.get('start_date')
            job.end_date = request.POST.get('end_date')
            job.description = request.POST.get('description')
            job.city = request.POST.get('city')
            job.contract_type_id = Contract_Type.objects.get(
                contract_description=request.POST.get('contract'))

            job.save()

            return redirect('dashboard')
        # Return  the page with contract types
        data = Contract_Type.objects.all()
        return render(request, 'jobs/add_job.html', {
            'contract_types': Contract_Type.objects.all()
        })

    # If the user is not authenticated, just take them to index
    return redirect('index')

# Admin can edit job on the backend, this view is not complete


def edit_job(request):
    return render(request, 'jobs/edit_job.html')

# Adds job to user's job applications if they are a part of the applicant group


def apply_to_job(request, job_id):
    job = Job_Listing.objects.get(job_listing_id=job_id)
    if request.user.groups.filter(name='applicant').exists():
        user = Job_Applicant.objects.get(user=request.user)
        user.application.add(job)
    return redirect('dashboard')

# Viewing jobs


def view_jobs(request):
    data = Job_Listing.objects.all()

    for listing in data:
        print("Listing", listing.skill.all())

    user = ""

    # Check to see what type of user the viewer is
    if request.user.groups.filter(name='applicant').exists():
        user = 'applicant'
    elif request.user.groups.filter(name='recruiter').exists():
        user = 'recruiter'

    context = {
        'job_listings': data,
        'user': user
    }

    # Return all of the jobs withe the type of user also
    return render(request, 'jobs/view_jobs.html', context)

# Function to call recommender model - Inputs come from the job listing that is being viewed


def get_job_recommendations(job_listing_id, user_id, status, city, job_title, organization_id, contract_type, description, matching_skills):
    import urllib
    import json

    # Setup the data header
    data = {
        "Inputs": {

            "input1":
            {
                "ColumnNames": ["job_listing_id", "user_id", "status", "city", "job_title", "offers_made", "organization_id", "contracts",
                                "description", "matching_skills"],
                "Values": [["0", "Null", status, city, job_title, "0", str(organization_id), contract_type, "test", "Null"]]
            }, },
        "GlobalParameters": {
        }
    }

    body = str.encode(json.dumps(data))

    url = 'https://ussouthcentral.services.azureml.net/workspaces/5695d5c46df747d6aa22c6316ee023f6/services/d47f253401c1495a80bef56e64907373/execute?api-version=2.0&details=true'
    # Replace this with the API key for the web service
    api_key = '7qQAmC/ib+xNGjF3BSnPCII9+4Rpngz+8Vx2A4O5FshaWg9SkqUKl8zbT7ICIz53L9BlSncYUuP9f8Ef3ASq0Q=='
    headers = {'Content-Type': 'application/json',
               'Authorization': ('Bearer ' + api_key)}

    req = urllib.request.Request(url, body, headers)
    response = urllib.request.urlopen(req)
    result = response.read()
    result = json.loads(result)

    # Get the item results (10 other recommended jobs)
    items = result['Results']['output1']['value']['Values'][0]
    return items

# Function to call recommender model - Inputs come from the job listing that is being viewed


def get_applicants(job_listing, status, city, job_title, organization_id, contracts, description):
    import urllib
    import json

    # Setup data header
    data = {

        "Inputs": {

            "input1":
                {
                    "ColumnNames": ["job_listing_id", "user_id", "status", "city", "job_title", "offers_made", "organization_id", "contracts",
                                    "description", "matching_skills"],
                    "Values": [["0", "0", status, city, job_title, "0", organization_id, contracts, description, "Null"]]
                }, },
        "GlobalParameters": {
        }
    }

    body = str.encode(json.dumps(data))

    url = 'https://ussouthcentral.services.azureml.net/workspaces/5695d5c46df747d6aa22c6316ee023f6/services/1c3964d738514ea781a8787fc244b2c1/execute?api-version=2.0&details=true'
    # Replace this with the API key for the web service
    api_key = 'zeDM9AFLfFu1o8WFJBsccPKCshsgfhRqa3ndpMsknCYSn8Kd9ylZzu6BK3+V+0cXK/2E/AC14Ydgl1UAAvIyfQ=='
    headers = {'Content-Type': 'application/json',
               'Authorization': ('Bearer ' + api_key)}

    req = urllib.request.Request(url, body, headers)

    response = urllib.request.urlopen(req)
    result = response.read()
    result = json.loads(result)

    # Results here - 10 different users that are recommended based on the current job
    items = result['Results']['output1']['value']['Values'][0]

    return items


def view_job(request, job_id):
    job = Job_Listing.objects.get(job_listing_id=job_id)

    # Get those who applied for the job
    applications = Job_Application.objects.filter(
        job_listing_id=job.job_listing_id)

    user = ""
    recommended_items = []

    # Get the type of user
    if request.user.groups.filter(name='applicant').exists():
        user = 'applicant'

    # If the user is a recruiter, get the recommended applicants
    if request.user.groups.filter(name='recruiter').exists():
        user = 'recruiter'

        # Get 10 user id's from the API
        recommended_applicants = get_applicants(
            job_id, job.status, job.city, job.job_title, job.organization_id.id, job.contract_type_id.contract_description, job.description
        )

        # Get all of the applicants in the database. If that user doesn't exist, return a placeholder user
        for item in recommended_applicants:
            if Job_Applicant.objects.filter(user_id=item).count() > 0:
                recommended_items.append(
                    Job_Applicant.objects.get(user_id=item))
            else:
                recommended_items.append(Job_Applicant.objects.get(user_id=26))
    # If the user is not a recruiter, get the recommended jobs
    else:
        # Get the job listing id's
        recommended_jobs = get_job_recommendations(job_id, request.user.id, job.status, job.city, job.job_title,
                                                   job.organization_id.id, job.contract_type_id.contract_description, job.description, 1)

        # Get the jobs from the database. If it does not exist in this database, instead add a placeholder job
        for recommended_job in recommended_jobs:
            if Job_Listing.objects.filter(job_listing_id=recommended_job).count() > 0:
                recommended_items.append(
                    Job_Listing.objects.get(job_listing_id=recommended_job))
            else:
                recommended_items.append(
                    Job_Listing.objects.get(job_listing_id=7))

    # Render the job page iwth the job, applications, user, and recommended items based on who is viewing
    return render(request, 'jobs/view_job.html', {
        'job': job,
        'applications': applications,
        'user': user,
        'recommended_items': recommended_items
    })

# Search the jobs (implemented in the home page or jobs page)


def search_jobs(request, search):
    # Filter the data based on the search (ignore caps)
    data = Job_Listing.objects.filter(
        job_title__icontains=search)

    user = ""

    if request.user.groups.filter(name='applicant').exists():
        user = 'applicant'
    elif request.user.groups.filter(name='recruiter').exists():
        user = 'recruiter'

    # Render the jobs page with the type of user
    context = {
        'job_listings': data,
        'user': user
    }

    return render(request, 'jobs/view_jobs.html', context)
