from django.urls import path
from .views import dashboardPageView, add_skill, view_profile, edit_profile, create_profile, create_recruiter_profile, start_profile, recruiterDashboardPageView

urlpatterns = [
    path('profile/', view_profile, name='profile'),
    path('editprofile/', edit_profile, name='editprofile'),
    path('startprofile/', start_profile, name='start_profile'),
    path('createprofile/', create_profile, name='createprofile'),
    path('createrecruiter/', create_recruiter_profile, name='createrecruiter'),
    path('addskill/<int:skill_id>', add_skill, name='add_skill'),
    path('recruiterdashboard/', recruiterDashboardPageView,
         name='recruiterdashboard'),
    path('', dashboardPageView, name='dashboard'),
]
