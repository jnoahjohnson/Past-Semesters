from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Job_Applicant, Recruiter
from jobs.models import Job_Listing
from django.contrib.auth.models import User
from core.forms import SignUpForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import Group
from jobs.models import Job_Application, Job_Listing
from skills.models import Skill
# Create your views here.

# This is the dashboard for the user


def dashboardPageView(request):
    # Send visitor back to home page if not authenticated
    if not request.user.is_authenticated:
        return redirect('index')

    # Send visitor to the recruiter dashboard if they are a recruiter
    if request.user.groups.filter(name='recruiter').exists():
        return redirect('recruiterdashboard')

    # Get the user, jobs, and applications (jobs applied for)
    user = Job_Applicant.objects.get(user=request.user)
    jobs = Job_Listing.objects.all()
    applications = Job_Application.objects.filter(user=user)

    return render(request, 'user/dashboard.html', {
        'user': user,
        'jobs': jobs,
        'applications': applications
    })

# Dashboard for the recruiter


def recruiterDashboardPageView(request):
    recruiter = Recruiter.objects.get(user=request.user)
    job_listings = Job_Listing.objects.filter(
        organization_id=recruiter.organization)
    return render(request, 'user/recruiter_dashboard.html', {
        'recruiter': recruiter,
        'job_listings': job_listings
    })

# How to view profile information - Not fully implemented, the dashboard covers mostly everything
# Admin on the backend can modify any other data


def view_profile(request):
    return render(request, 'user/profile.html')

# This is just a placeholder. The admin has to change user profile right now


def edit_profile(request):
    return render(request, 'user/edit_profile.html')

# Page that asks if user is a recruiter or job seeker


def start_profile(request):
    return render(request, 'user/start_profile.html')

# Creating an applicant profile


def create_profile(request):
    # If the method is post then get the data from the form
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)

            # Applicant
            applicant = Job_Applicant()
            applicant.user = user
            applicant.save()

            # Add group
            applicant_group = Group.objects.get(name='applicant')
            applicant_group.user_set.add(user)

            login(request, user)
            return redirect('dashboard')
    else:
        form = SignUpForm()

    # If there is no post method, the sign up form is passed to the template
    return render(request, 'user/create_profile.html', {'form': form})

# Creating a recruiter profile


def create_recruiter_profile(request):
    # if the method is post then get the data from the form
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)

            # Recruiter
            recruiter = Recruiter()
            recruiter.user = user
            recruiter.save()

            # Add group to recruiter
            applicant_group = Group.objects.get(name='recruiter')
            applicant_group.user_set.add(user)

            login(request, user)
            return redirect('dashboard')
    else:
        form = SignUpForm()

    # If the recruiter visits the page the first time without 'POST' then it will return a blank form
    return render(request, 'user/create_recruiter_profile.html', {'form': form})


# Adding a skill - currently triggered by just clicking on the button on each skill page
def add_skill(request, skill_id):
    applicant = Job_Applicant.objects.get(user=request.user)
    print(skill_id)
    applicant.skill.add(Skill.objects.get(id=skill_id))
    print(Skill.objects.get(id=skill_id))
    return redirect('dashboard')
