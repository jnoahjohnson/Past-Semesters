from django.shortcuts import render, redirect
from django.http import HttpResponse


def about_us(request):
    return render(request, 'business_information/about.html')


def terms_and_conditions(request):
    return render(request, 'business_information/terms.html')


def privacy_policy(request):
    return render(request, 'business_information/privacy.html')

# Routing users based on authorization (whether they are a recruiter or applicant)


def index_view(request):

    if request.user.groups.filter(name='recruiter').exists():
        return redirect('recruiterdashboard')

    if request.user.groups.filter(name='applicant').exists():
        return redirect('dashboard')

    return render(request, 'business_information/index.html')
