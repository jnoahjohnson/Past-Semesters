from django.shortcuts import render
from django.http import HttpResponse
from .models import Skill, SkillCategory

# See the skills (all)


def view_skills(request):
    categories = SkillCategory.objects.all()
    skill_categories = []

    # Create an array and add a dictionary of the category title and skills array
    for category in categories:
        skill_data = {
            'title': category,
            'skills': Skill.objects.filter(skill_category=category)
        }
        skill_categories.append(skill_data)

    # Render the page with the categories
    return render(request, 'skills/view_skills.html', {
        'skill_categories': skill_categories
    })


def skill_details(request, skill_id):
    skill = Skill.objects.get(id=skill_id)
    # Get the other skills from the current skill cateogry
    rs = Skill.objects.raw(
        '''SELECT * FROM skills_skill s WHERE s.skill_category_id = %s AND s.id !=%s''', [skill.skill_category_id, skill.id])

    # Return the current skill data and other related skills
    return render(request, 'skills/skill_details.html', {
        'skill': skill,
        'related_skills': rs,
    })
