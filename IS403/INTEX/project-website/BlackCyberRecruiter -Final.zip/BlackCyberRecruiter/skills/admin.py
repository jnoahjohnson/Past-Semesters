from django.contrib import admin
from .models import Skill, SkillCategory, Resource
# Register your models here.

admin.site.register(Skill)
admin.site.register(SkillCategory)
admin.site.register(Resource)
