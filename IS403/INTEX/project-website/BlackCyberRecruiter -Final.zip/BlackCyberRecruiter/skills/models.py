from django.db import models

# Create your models here.


class SkillCategory(models.Model):
    category_name = models.CharField(max_length=30)

    def __str__(self):
        return self.category_name


class Resource(models.Model):
    title = models.CharField(max_length=200)
    description = models.CharField(max_length=1000)
    link = models.CharField(max_length=1000)

    def __str__(self):
        return self.title


class Skill(models.Model):
    skill_name = models.CharField(max_length=30)
    skill_category = models.ForeignKey(SkillCategory, on_delete=models.CASCADE)
    icon = models.CharField(max_length=20)
    description = models.CharField(max_length=1000)
    resources = models.ManyToManyField(Resource, blank=True)

    def __str__(self):
        return self.skill_name
