from django.urls import path
from .views import skill_details, view_skills

urlpatterns = [
    path("skilldetails/<int:skill_id>", skill_details, name="skill_details"),
    path("", view_skills, name="view_skills"),
]
