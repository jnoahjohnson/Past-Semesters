from django.urls import path
from .views import about_us, terms_and_conditions, privacy_policy, index_view
        
urlpatterns = [
    path("termsandconditions/", terms_and_conditions, name="terms"),
    path("privacypolicy/", privacy_policy, name="privacy"),
    path("about/", about_us, name="about"),
    path("", index_view, name="index"),
]      