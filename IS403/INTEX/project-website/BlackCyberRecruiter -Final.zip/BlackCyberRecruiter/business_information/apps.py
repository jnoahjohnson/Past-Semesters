from django.apps import AppConfig


class BusinessInformationConfig(AppConfig):
    name = 'business_information'
