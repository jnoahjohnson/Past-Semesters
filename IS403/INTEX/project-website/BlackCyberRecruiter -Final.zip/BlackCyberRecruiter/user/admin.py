from django.contrib import admin
from .models import Job_Organization, Job_Applicant, Recruiter
# Register your models here.

admin.site.register(Job_Organization)
admin.site.register(Job_Applicant)
admin.site.register(Recruiter)
