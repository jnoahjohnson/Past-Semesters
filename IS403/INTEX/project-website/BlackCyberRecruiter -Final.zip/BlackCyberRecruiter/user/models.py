from django.db import models
from django.contrib.auth.models import User

# Create your models here.

# FIGURE OUT INHERITANCE---------------------------------
class Job_Organization(models.Model):
    company_name = models.CharField(max_length=40)
    email = models.EmailField(max_length=30)
    address = models.CharField(max_length=50)
    size = models.CharField(max_length=2)
    sectors = models.CharField(max_length=2)

    def __str__(self):
        return self.company_name

class Job_Applicant(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    skill = models.ManyToManyField('skills.Skill', blank=True)
    offer = models.ManyToManyField('jobs.Job_Listing', related_name='offer', through='jobs.Job_Offer', blank=True)
    application = models.ManyToManyField('jobs.Job_Listing', related_name='application', through='jobs.Job_Application', blank=True)

    def __str__(self):
        return self.user.first_name
    

#I AM JUST ADDING models.CASCADE, we can change that if you want.
class Recruiter(models.Model):
    user = models.OneToOneField(User, models.CASCADE, primary_key=True)
    organization = models.ForeignKey(Job_Organization, on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        return self.user.first_name
    