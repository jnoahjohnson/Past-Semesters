from django.urls import path
from .views import add_job, edit_job, view_jobs, view_job, apply_to_job, get_job_recommendations, search_jobs

urlpatterns = [
    path("addjob/", add_job, name="add_job"),
    path("editjob/", edit_job, name="edit_job"),
    path("applytojob/<int:job_id>", apply_to_job, name="apply"),
    path("viewjob/<int:job_id>", view_job, name="view_job"),
    path("getjobrecommendations/", get_job_recommendations,
         name="get_job_recommendations"),
    path("searchjobs/<search>", search_jobs, name="search_jobs"),
    path("", view_jobs, name="view_jobs"),
]
