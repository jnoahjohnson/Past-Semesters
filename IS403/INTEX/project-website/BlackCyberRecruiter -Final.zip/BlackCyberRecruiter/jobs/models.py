from django.db import models
from datetime import datetime

# Create your models here.


class Contract_Type(models.Model):
    contract_type_id = models.AutoField(primary_key=True)
    contract_description = models.CharField(max_length=50)

    def __str__(self):
        return self.contract_description


class Job_Listing(models.Model):
    job_listing_id = models.AutoField(primary_key=True)
    job_title = models.CharField(max_length=30)
    contract_type_id = models.ForeignKey(
        Contract_Type, on_delete=models.DO_NOTHING)
    organization_id = models.ForeignKey(
        'user.Job_Organization', on_delete=models.DO_NOTHING)
    status = models.CharField(max_length=20)
    total_skills = models.IntegerField(default=0)
    start_date = models.DateField(default=datetime.today)
    end_date = models.DateField(null=True, blank=True, default="")
    description = models.CharField(max_length=1000)
    city = models.CharField(max_length=20)
    skill = models.ManyToManyField('skills.Skill', blank=True)

    def __str__(self):
        return self.job_title


class Job_Offer(models.Model):
    user = models.ForeignKey('user.Job_Applicant', models.DO_NOTHING)
    job_listing_id = models.ForeignKey(Job_Listing, models.DO_NOTHING)
    matching_skills = models.IntegerField(default=0)

    def __str__(self):
        return (f'User - {self.user_id}, Job - {Job_Listing.job_title} ')


class Job_Application(models.Model):
    user = models.ForeignKey('user.Job_Applicant', models.DO_NOTHING)
    job_listing_id = models.ForeignKey(Job_Listing, models.DO_NOTHING)
    date = models.DateField(default=datetime.today)

    def __str__(self):
        return (f'User - {self.user_id}, Job - {self.job_listing_id}')
