from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages

# View to attempt to login


def login_attempt(request):
    # Check if there is a post method
    if request.method == 'POST':
        # Get form from django authentication and login if data is valid
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect('index')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        # Set form to authentication form
        form = AuthenticationForm()
    # Return login template with authentication form
    return render(request, 'authentication/login.html', context={"form": form})

# Log out


def logoff(request):
    logout(request)
    return redirect('index')
