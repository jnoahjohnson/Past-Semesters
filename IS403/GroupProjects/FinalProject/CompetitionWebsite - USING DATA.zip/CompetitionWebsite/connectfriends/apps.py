from django.apps import AppConfig


class ConnectfriendsConfig(AppConfig):
    name = 'connectfriends'
