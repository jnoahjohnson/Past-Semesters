from django.contrib import admin
from .models import Competitor

admin.site.register(Competitor)
