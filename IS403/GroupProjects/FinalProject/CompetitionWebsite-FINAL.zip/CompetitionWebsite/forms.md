#These are the forms we plan to put into our project:

##User
- Create User
- Edit User

##Competition
- Create competition
- Edit competition
- Create task
- edit/delete task
- Task to-do list

##Group 
- Create group
- Join group
- Edit group