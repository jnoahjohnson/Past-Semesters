from django.apps import AppConfig


class HomepagesConfig(AppConfig):
    name = 'homepages'
